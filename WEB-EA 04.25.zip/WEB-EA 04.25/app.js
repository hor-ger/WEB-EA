import React, { useState } from "react";
import Calculator from "./szamologep";

function App() {
    const [activePage, setActivePage] = useState("calculator");

    return (
        <div>
            <nav>
                <button onClick={() => setActivePage("calculator")}>Számológép</button>
            </nav>
            {activePage === "calculator" && <Calculator />}
        </div>
    );
}

export default App;
