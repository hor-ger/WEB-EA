document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("addButton").addEventListener("click", addRow);
});

function addRow() {
    let nameInput = document.getElementById("nameInput").value.trim();
    let subjectInput = document.getElementById("subjectInput").value.trim();
    let gradeInput = document.getElementById("gradeInput").value.trim();

    if (!validateInput(nameInput, subjectInput, gradeInput)) return;

    let table = document.getElementById("dataTable").getElementsByTagName('tbody')[0];
    let row = table.insertRow();

    let nameCell = row.insertCell(0);
    let subjectCell = row.insertCell(1);
    let gradeCell = row.insertCell(2);
    let actionsCell = row.insertCell(3);

    nameCell.innerHTML = nameInput;
    subjectCell.innerHTML = subjectInput;
    gradeCell.innerHTML = gradeInput;

    actionsCell.innerHTML = `<button onclick="editRow(this)">Szerkesztés</button>
                             <button onclick="deleteRow(this)">Törlés</button>`;
}

function validateInput(name, subject, grade) {
    if (name.length < 3 || name.length > 20) {
        alert("A név hossza 3 és 20 karakter között kell legyen.");
        return false;
    }
    if (subject.length < 3 || subject.length > 20) {
        alert("A Neptun kód hossza 3 és 20 karakter között kell legyen.");
        return false;
    }
    if (isNaN(grade) || grade < 1 || grade > 5) {
        alert("Az osztályzatnak 1 és 5 között kell lennie.");
        return false;
    }
    return true;
}

function editRow(button) {
    let row = button.parentElement.parentElement;
    let newName = prompt("Új név:", row.cells[0].innerHTML);
    let newSubject = prompt("Új Neptun kód:", row.cells[1].innerHTML);
    let newGrade = prompt("Új osztályzat:", row.cells[2].innerHTML);

    if (!validateInput(newName, newSubject, newGrade)) return;

    row.cells[0].innerHTML = newName;
    row.cells[1].innerHTML = newSubject;
    row.cells[2].innerHTML = newGrade;
}

function deleteRow(button) {
    let row = button.parentElement.parentElement;
    row.parentElement.removeChild(row);
}

function searchTable() {
    let input = document.getElementById("searchInput").value.toLowerCase();
    let rows = document.querySelectorAll("#dataTable tbody tr");

    rows.forEach(row => {
        let text = row.textContent.toLowerCase();
        row.style.display = text.includes(input) ? "" : "none";
    });
}

function sortTable(columnIndex) {
    let table = document.getElementById("dataTable");
    let tbody = table.querySelector("tbody");
    let rows = Array.from(tbody.rows);
    let ascending = sortDirection[columnIndex];

    rows.sort((a, b) => {
        let aValue = a.cells[columnIndex].innerText.toLowerCase();
        let bValue = b.cells[columnIndex].innerText.toLowerCase();

        if (!isNaN(aValue) && !isNaN(bValue)) {
            return ascending ? aValue - bValue : bValue - aValue;
        } else {
            return ascending ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
        }
    });

    sortDirection[columnIndex] = !ascending;
    rows.forEach(row => tbody.appendChild(row));
}
