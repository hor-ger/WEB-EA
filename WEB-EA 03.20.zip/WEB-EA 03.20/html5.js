document.addEventListener("DOMContentLoaded", function () {
    const x = document.getElementById("result");

    // Ha a sessionStorage még nincs beállítva, akkor kezdetben 0 legyen
    if (!sessionStorage.clickcount) {
        sessionStorage.clickcount = 0;
    }

    // Az alapértelmezett szöveg megjelenítése
    x.innerHTML = "Ezt a gombot " + sessionStorage.clickcount + " alkalommal nyomta meg!";
});

function clickCounter() {
    const x = document.getElementById("wsresult");

    if (typeof(Storage) !== "undefined") {
        sessionStorage.clickcount = Number(sessionStorage.clickcount) + 1;
        x.innerHTML = "Ezt a gombot " + sessionStorage.clickcount + " alkalommal nyomta meg!";
    } else {
        x.innerHTML = "Az oldal nem támogat web storage-t";
    }
}

let w;

function startWorker() {
    if (typeof(Worker) !== "undefined") {
        if (!w) {
            w = new Worker(URL.createObjectURL(new Blob([`
                let seconds = 0;
                let interval;

                onmessage = function(event) {
                    if (event.data === "start") {
                        if (!interval) {
                            interval = setInterval(() => {
                                seconds++;
                                postMessage(seconds); // Visszaküldi az aktuális másodperc értéket
                            }, 1000); // 1 másodperces időzítő
                        }
                    } else if (event.data === "stop") {
                        clearInterval(interval); // Időzítő leállítása
                        interval = null;
                        seconds = 0; // Visszaállítjuk a számlálót
                    }
                };
            `], { type: 'text/javascript' })));
        }
        w.postMessage("start"); // Szól a workernek, hogy kezdje el a számlálást
        w.onmessage = function(event) {
            document.getElementById("counter").innerText = `${event.data}`;
        };
    } else {
        alert("Az oldal nem támogat Web Worker-t.");
    }
}

function stopWorker() {
    if (w) {
        w.postMessage("stop"); // Üzenet küldése a workernek a számlálás leállításához
        w.terminate();
        w = null;
    }
}

function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else {
        document.getElementById("location").innerHTML = "A böngésző nem támogatja a Geolocation API-t.";
    }
}

function showPosition(position) {
    document.getElementById("location").innerHTML =
        "Szélesség: " + position.coords.latitude + "<br>" +
        "Hosszúság: " + position.coords.longitude;
}

function dragstartHandler(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
}

function dragoverHandler(ev) {
    ev.preventDefault();
}

function dropHandler(ev) {
    ev.preventDefault();
    const data = ev.dataTransfer.getData("text");
    ev.target.appendChild(document.getElementById(data));
}



asdasdasdasdasd